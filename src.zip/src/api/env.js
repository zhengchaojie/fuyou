/**
 * Created by jerry on 2017/11/13
 * 设置api请求的baseURL
 * 实际项目中建议该文件不纳入版本管理
 */
export default {
  baseURL: 'http://localhost:3000',
  // baseURL: '',
  isDev: true
}

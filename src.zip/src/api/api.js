/**
 * Created by jerry on 2017/4/13.
 */
import axios from 'axios'
// http://192.168.0.127:8081/whjtys/page/newSigning
// let base = 'http://192.168.0.127:8081/whjtys/logins'
// let base=''
// let signreject ='http://192.168.0.127:8081/whjtys/signed/backManager'
// export const requestLogin = params => { return axios.post(`${base}/logins`, params)}.then(res => res.data) }

// export const reqSaveUserProfile = params => { return axios.post(`${base}/user/profile`, params).then(res => res.data) }

// export const reqGetUserList = params => { return axios.get(`${base}/user/list`, { params: params }) }

// export const reqGetBookListPage = params => { return axios.get(`${base}/sign/list1`, { params: params }) }

// export const reqDeleteBook = params => { return axios.get(`${base}/sign/delete`, { params: params }) }

// export const reqEditBook = params => { return axios.get(`${base}/sign/edit`, { params: params }) }

// export const reqBatchDeleteBook = params => { return axios.get(`${base}/sign/batchdelete`, { params: params }) }

// export const reqAddBook = params => { return axios.get(`${base}/sign/add`, { params: params }) }

// export const reqSignReject = params =>{return axios.get(`${signreject}/sign/list2`,{params:params}).then(res => {})} 
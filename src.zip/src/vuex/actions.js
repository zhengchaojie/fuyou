//
// export const addMenu = ({ commit }, menuItems) => {  
//   if (menuItems.length > 0) {  
//     commit(types.add_menu, menuItems)  
//   }  
// }  
//加载路由
// export const loadRoutes = ({ commit }) => {  
//   commit(types.LOAD_ROUTES)  
// }  
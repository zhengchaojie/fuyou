import Vue from 'vue'
import Vuex from 'vuex'
// import * as actions from './actions.js'
// import * as getters from './getters.js'
Vue.use(Vuex)

const state ={
   
}
const mutations={

 
}
const getters={

}
const actions={
  
  // add:({commit})=>commit('add'),
  // jian:({commit})=>commit('jian'),

}
const modules={

}
export default new Vuex.Store({
  state,
  mutations,
  getters,
  actions,
  modules
})